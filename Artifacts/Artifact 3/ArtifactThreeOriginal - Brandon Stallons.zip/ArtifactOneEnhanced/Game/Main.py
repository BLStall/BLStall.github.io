# Brandon Stallons

from Game import Game

def main():
    # Main function to start the game.

    try:
        game = Game()
        game.play()
    except Exception as e:
        print(f"An error occurred: {e}")
        input("Press Enter to exit...")

if __name__ == '__main__':
    main()
