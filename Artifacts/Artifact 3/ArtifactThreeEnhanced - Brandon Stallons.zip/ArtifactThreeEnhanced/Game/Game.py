# Game.py
# Brandon Stallons

from Player import Player
from user_auth import update_win_loss
import sys
import time
import random

class Game:
    """Class for game logic."""

    def __init__(self, user_id, username, difficulty='Medium'):
        """Initializes the game with rooms, items, enemies, and the player."""

        self.user_id = user_id
        self.username = username
        self.difficulty = difficulty  # New attribute for difficulty level

        # Define room names
        self.room_names = {
            'cell_1': 'Cell #1',
            'interrogation_room': 'Interrogation Room',
            'cell_2': 'Cell #2',
            'cell_3': 'Cell #3',
            'armory': 'Armory',
            'hall_1': 'Hall #1',
            'cell_4': 'Cell #4',
            'infirmary': 'Infirmary',
            'hall_2': 'Hall #2',
            'security_room': 'Security Room',
            'ventilation_shaft': 'Ventilation Shaft',
            'front_entrance': 'Front Entrance'
        }

        # Define room connections
        self.rooms = {
            'cell_1': {'East': 'interrogation_room'},
            'interrogation_room': {
                'North': 'cell_2',
                'South': 'hall_1',
                'East': 'hall_2',
                'West': 'cell_1',
                'Down': 'front_entrance'
            },
            'cell_2': {'East': 'cell_3', 'South': 'interrogation_room'},
            'cell_3': {'West': 'cell_2', 'East': 'armory'},
            'armory': {'West': 'cell_3', 'South': 'front_entrance'},
            'hall_1': {'North': 'interrogation_room', 'East': 'cell_4', 'South': 'infirmary'},
            'cell_4': {'West': 'hall_1'},
            'infirmary': {'North': 'hall_1'},
            'hall_2': {'West': 'interrogation_room', 'East': 'security_room'},
            'security_room': {'West': 'hall_2', 'East': 'ventilation_shaft'},
            'ventilation_shaft': {'Up': 'front_entrance'},
            'front_entrance': {},
        }

        # Define items in rooms
        self.items = {
            'cell_1': 'key',
            'interrogation_room': 'security card',
            'cell_2': 'daughter',
            'cell_3': 'son',
            'armory': 'gun',
            'hall_1': 'wooden bat',
            'hall_2': 'machete',
            'security_room': 'NONE',
            'ventilation_shaft': 'NONE',
            'cell_4': 'wife',
            'infirmary': 'first aid kit'
        }

        # Enemies in certain rooms along with their HP
        self.enemies = {
            'interrogation_room': {'name': 'Guard', 'hp': 25},
            'armory': {'name': 'Patrolling Guard', 'hp': 35},
            'security_room': {'name': 'Boss Kidnapper', 'hp': 50}
        }

        # Initialize the player
        self.player = Player('cell_1', self.room_names)

        # Adjust enemy stats based on difficulty
        self.adjust_difficulty()

    def adjust_difficulty(self):
        """
        Adjusts enemy stats and game parameters based on the selected difficulty.
        """
        if self.difficulty == 'Easy':
            for enemy in self.enemies.values():
                enemy['hp'] = int(enemy['hp'] * 0.75)
            self.player.hp = 125  # Increase player health
        elif self.difficulty == 'Hard':
            for enemy in self.enemies.values():
                enemy['hp'] = int(enemy['hp'] * 2.0)
            self.player.hp = 80  # Decrease player health
        # For 'Medium' difficulty, default values are used

    def show_instructions(self):
        instructions = """
================================================================
                        Escape the Kidnappers
================================================================
Navigate through the facility, rescue your family, fight the 
kidnappers, and escape. Collect necessary items to unlock 
rooms, survive encounters, and defeat enemies.

Movement Commands:
- North, South, East, West, Up, Down

Action Commands:
- search: Search the room for items
- fight: Engage in combat when facing an enemy
- run: Attempt to flee from an enemy
- use [item]: Use an item from your inventory (e.g., 'use first aid kit')
- exit: To quit the game
- help: Show game instructions

Objectives:
- Explore different rooms and search each one.
- Rescue your wife, son, and daughter.
- Collect a weapon (machete, wooden bat, or gun).
- Find the key and security card to access locked rooms.
- Maintain your health and defeat enemies.
- Reach the Front Entrance to confront the kidnappers.

Note:
- Be cautious of enemies in certain rooms.
- Your health is crucial; use items wisely.
- You can reach the final room by going 'Up', 'Down', and 'South'
  in three different rooms, respectively.
================================================================
"""
        print(instructions)

    def play(self):
        # Starts the game loop.

        self.show_instructions()
        input("Press Enter to start your adventure...")

        while True:
            current_room = self.player.current_room
            display_room = self.room_names.get(current_room, current_room)

            # Displays current room and description
            print(f"\n==================== {display_room} ====================")
            if current_room == 'front_entrance':
                game_result = self.final_room()
                # Update win/loss in the database
                if game_result == 'won':
                    update_win_loss(self.user_id, won=True)
                else:
                    update_win_loss(self.user_id, won=False)
                break

            # Displays exits
            exits = ', '.join(self.rooms[current_room].keys())
            print(f"\nExits: {exits}")

            # Displays rescued family members
            print("\nFamily Members Rescued:")
            self.player.show_family_members()

            # Displays inventory and health
            print("\nYour Inventory:")
            self.player.show_inventory()
            print(f"Health: {self.player.hp} HP")

            # Checks for enemy encounter
            if current_room in self.enemies:
                enemy = self.enemies[current_room]
                print(f"\nAn enemy appears: {enemy['name']} (HP: {enemy['hp']})")
                combat_result = self.combat(enemy)
                if combat_result == 'defeated_by_enemy':
                    print("\nYou have been defeated by the enemy... GAME OVER!!")
                    update_win_loss(self.user_id, won=False)
                    input("Press Enter to exit...")
                    break
                elif combat_result == 'defeated':
                    print(f"\nYou defeated the {enemy['name']}!")
                    del self.enemies[current_room]
                    input("Press Enter to continue...")
                    continue  # Restarts loop after combat
                elif combat_result == 'escaped':
                    # Player successfully ran away
                    input("Press Enter to continue...")
                    continue  # Continues game without deleting the enemy
                else:
                    # Handles any unexpected outcomes
                    print("\nAn unexpected error occurred during combat.")
                    input("Press Enter to continue...")
                    continue

            # Prompts for user input
            print("----------------------------------------------------")
            action = input("What would you like to do? ").strip().lower()

            if action == 'exit':
                print("Thank you for playing. Goodbye! :)")
                break
            elif action in ['north', 'south', 'east', 'west', 'up', 'down']:
                moved, message = self.player.move(action, self.rooms)
                if moved:
                    continue  # If movement is successful, the screen will refresh
                else:
                    print(f"\n{message}")
                    input("Press Enter to continue...")
            elif action == 'search':
                result = self.player.search_room(self.items)
                print(f"\n{result}")
                input("Press Enter to continue...")
            elif action.startswith('use '):
                item_to_use = action[4:]
                result = self.player.use_item(item_to_use)
                print(f"\n{result}")
                input("Press Enter to continue...")
            elif action == 'help':
                self.show_instructions()
                input("Press Enter to continue...")
            else:
                print("\nInvalid command! Type 'help' to see available commands.")
                input("Press Enter to continue...")

    def combat(self, enemy):
        """
        Handles combat with an enemy.

        Returns a string indicating the outcome:
        'defeated': Enemy defeated by player.
        'escaped': Player successfully ran away.
        'defeated_by_enemy': Player was defeated by enemy.
        """
        while enemy['hp'] > 0:
            print("\nChoose an action: 'fight' or 'run'")
            action = input("Your action: ").strip().lower()

            if action == 'fight':
                if not self.player.has_weapon():
                    print("\nYou have no weapon to fight with! You must run or face defeat.")
                    continue

                # Player attacks enemy
                damage = random.randint(10, 20)  # Increased damage
                enemy['hp'] -= damage
                print(f"\nYou attack the {enemy['name']} and deal {damage} damage.")

                if enemy['hp'] <= 0:
                    return 'defeated'  # Enemy defeated

                # Enemy attacks player
                enemy_damage = random.randint(5, 15)
                self.player.hp -= enemy_damage
                print(f"The {enemy['name']} attacks you and deals {enemy_damage} damage.")
                print(f"Your health is now {self.player.hp} HP.")

                if self.player.hp <= 0:
                    return 'defeated_by_enemy'  # Player defeated

            elif action == 'run':
                success = random.choice([True, False])
                if success:
                    # Get available exits
                    available_exits = list(self.rooms[self.player.current_room].keys())

                    # Exclude 'West' and 'Down' leading to unwanted rooms
                    if self.player.current_room == 'interrogation_room':
                        for direction in ['West', 'Down']:
                            if direction in available_exits:
                                available_exits.remove(direction)

                    # Randomly select a direction to escape
                    if available_exits:
                        escape_direction = random.choice(available_exits)
                        next_room = self.rooms[self.player.current_room][escape_direction]

                        # Update player's location
                        self.player.previous_room = self.player.current_room
                        self.player.current_room = next_room

                        print(f"\nYou have successfully evaded the {enemy['name']} and ran {escape_direction} to the {self.room_names.get(next_room, next_room)}!")
                        return 'escaped'
                    else:
                        print("\nThere are no available exits to escape!")
                        continue
                else:
                    print("\nYou failed to escape!")

                    # Enemy attacks player
                    enemy_damage = random.randint(5, 10)
                    self.player.hp -= enemy_damage
                    print(f"The {enemy['name']} attacks you and deals {enemy_damage} damage.")
                    print(f"Your health is now {self.player.hp} HP.")

                    if self.player.hp <= 0:
                        return 'defeated_by_enemy'  # Player defeated
            else:
                print("\nInvalid action! Choose 'fight' or 'run'.")

        return 'defeated'  # Enemy defeated

    def final_room(self):
        # Handles the final room logic with multiple scenarios.

        print("You encounter the kidnappers at the exit!", end='', flush=True)
        time.sleep(2)  # Delay before starting the dots

        # Print 10 dots with a delay between them
        for _ in range(10):
            sys.stdout.write(".")
            sys.stdout.flush()
            time.sleep(0.3)
        sys.stdout.write("\n")
        time.sleep(1)

        has_weapon = any(item in self.player.inventory for item in ['machete', 'wooden bat', 'gun'])
        missing_members = [member for member in ['daughter', 'son', 'wife'] if member not in self.player.family_members]

        if not has_weapon:
            print("You have no weapon to fight the kidnappers.")
            print("You have been overpowered... GAME OVER!!")
            input("Press Enter to exit...")
            return 'lost'
        else:
            if missing_members:
                print(f"You escaped but lost: {', '.join(missing_members)}.")
                print("You survived, but at a great cost.")
                input("Press Enter to exit...")
                return 'lost'
            else:
                print("CONGRATULATIONS! You and your family have escaped safely! :)")
                input("Press Enter to exit...")
                return 'won'
