# user_auth.py

import bcrypt
import mysql.connector
from mysql.connector import Error, IntegrityError
from db_connector import create_connection

def register_user(username, password):
    connection = create_connection()
    if connection is None:
        print("Failed to connect to the database.")
        return False

    cursor = connection.cursor()

    # Hash the password
    password_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

    try:
        # Insert user into the database
        cursor.execute("""
            INSERT INTO users (username, password_hash)
            VALUES (%s, %s)
        """, (username, password_hash.decode('utf-8')))
        connection.commit()
        print("User registered successfully.")
        return True
    except IntegrityError:
        print("Username already exists. Please choose a different username.")
        return False
    except Error as e:
        print(f"Database error: {e}")
        return False
    finally:
        cursor.close()
        connection.close()

def login_user(username, password):
    connection = create_connection()
    if connection is None:
        print("Failed to connect to the database.")
        return None

    cursor = connection.cursor(dictionary=True)

    # Fetch the user from the database
    cursor.execute("""
        SELECT * FROM users WHERE username = %s
    """, (username,))
    user = cursor.fetchone()

    cursor.close()
    connection.close()

    if user:
        password_hash = user['password_hash']
        if bcrypt.checkpw(password.encode('utf-8'), password_hash.encode('utf-8')):
            print("Login successful.")
            return user  # Return user data for further use
        else:
            print("Incorrect password.")
            return None
    else:
        print("Username does not exist.")
        return None

def update_win_loss(user_id, won):
    connection = create_connection()
    if connection is None:
        print("Failed to connect to the database.")
        return

    cursor = connection.cursor()

    try:
        if won:
            cursor.execute("""
                UPDATE users SET wins = wins + 1 WHERE id = %s
            """, (user_id,))
        else:
            cursor.execute("""
                UPDATE users SET losses = losses + 1 WHERE id = %s
            """, (user_id,))
        connection.commit()
    except Error as e:
        print(f"Database error: {e}")
    finally:
        cursor.close()
        connection.close()

def get_user_stats(user_id):
    """
    Retrieves the user's win-loss record from the database.
    
    param user_id: The ID of the user.
    return: A tuple (wins, losses) or None if an error occurs.
    """
    connection = create_connection()
    if connection is None:
        print("Failed to connect to the database.")
        return None

    cursor = connection.cursor()

    try:
        cursor.execute("""
            SELECT wins, losses FROM users WHERE id = %s
        """, (user_id,))
        result = cursor.fetchone()
        if result:
            wins, losses = result
            return wins, losses
        else:
            print("User not found.")
            return None
    except Error as e:
        print(f"Database error: {e}")
        return None
    finally:
        cursor.close()
        connection.close()

def get_leaderboard():
    """
    Retrieves the top players based on win percentage.

    return: A list of dictionaries containing username, wins, losses, and win percentage.
    """
    connection = create_connection()
    if connection is None:
        print("Failed to connect to the database.")
        return []

    cursor = connection.cursor(dictionary=True)

    try:
        cursor.execute("""
            SELECT username, wins, losses,
            CASE
                WHEN (wins + losses) > 0 THEN (wins / (wins + losses)) * 100
                ELSE 0
            END AS win_percentage
            FROM users
            ORDER BY win_percentage DESC, wins DESC
            LIMIT 10;
        """)
        leaderboard = cursor.fetchall()
        return leaderboard
    except Error as e:
        print(f"Database error: {e}")
        return []
    finally:
        cursor.close()
        connection.close()
