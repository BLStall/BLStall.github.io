# db_connector.py

import mysql.connector
from mysql.connector import Error
from db_config import db_config

def create_connection():
    try:
        connection = mysql.connector.connect(**db_config)
        return connection
    except Error as e:
        print(f"Error connecting to database: {e}")
        return None
