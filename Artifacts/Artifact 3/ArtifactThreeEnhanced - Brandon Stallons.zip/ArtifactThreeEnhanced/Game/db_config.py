# db_config.py

db_config = {
    'user': 'your_username',                # Replace with your actual db username
    'password': 'your_password',  # Replace with your actual db password
    'host': '127.0.0.1',
    'database': 'game_db'              # Replace with your database name
}