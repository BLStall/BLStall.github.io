!! FOLLOW THESE STEPS TO RUN THE GAME ON LOCAL MACHINE !!

**Table of Contents**

1. Prerequisites
2. Install Python and Pip
3. Install Required Python Packages
4. Install MySQL Server
5. Set Up the MySQL Database
    - Create the Database
    - Create the Tables
6. Configure Database Connection (`db_config.py`)
7. Run the Game

--------------------------------------------------------------------------------------------------------------------------------------

**Prerequisites**

Before you begin, you must have the following installed on your local machine:

- Python 3.6 or higher
- MySQL Server
- Pip (Python package installer)

--------------------------------------------------------------------------------------------------------------------------------------

**Install Python and Pip**

If you don't already have Python and Pip installed:

- Windows:

  1. Download the Python installer from Pythons official website.
  2. Run the installer.
  3. Follow the installation prompts.

--------------------------------------------------------------------------------------------------------------------------------------


**Install Required Python Packages**

Navigate to the project directory in your terminal or command prompt and run:

pip install mysql-connector-python bcrypt

--------------------------------------------------------------------------------------------------------------------------------------

**Install MySQL Server**

If you don't have MySQL installed:

- Windows and macOS:

  1. Download and install MySQL Community Server and Workbench.
  2. During installation, write down the root password you set.

--------------------------------------------------------------------------------------------------------------------------------------

**Set Up the MySQL Database**

**Create the Database**

1. Open the MySQL Command-Line Client or Use `mysql` Command:

   mysql -u root -p

   - Enter your MySQL root password when prompted.

2. Create a New Database:

   CREATE DATABASE game_db;

3. Create a New MySQL User:

   - Replace `'your_username'` and `'your_password'` with your desired credentials.

   CREATE USER 'your_username'@'localhost' IDENTIFIED BY 'your_password';
   GRANT ALL PRIVILEGES ON game_db.* TO 'your_username'@'localhost';
   FLUSH PRIVILEGES;

**Create the Tables**

1. Switch to the `game_db` Database:

   USE game_db;

2. Create the `users` Table:

   CREATE TABLE users (
       id INT AUTO_INCREMENT PRIMARY KEY,
       username VARCHAR(50) NOT NULL UNIQUE,
       password_hash VARCHAR(100) NOT NULL,
       wins INT DEFAULT 0,
       losses INT DEFAULT 0
   );

5. Exit the MySQL Prompt:

   EXIT;

--------------------------------------------------------------------------------------------------------------------------------------


**Configure Database Connection (`db_config.py`)**

1. Open `db_config.py` File in the Project Directory:


2. Add Your Database Configuration:
   
   # db_config.py

   db_config = {
       'user': 'your_username',       # Replace with your MySQL username
       'password': 'your_password',   # Replace with your MySQL password
       'host': '127.0.0.1',           # or 'localhost'
       'database': 'game_db'
   }

   -  Replace `'your_username'` and `'your_password'` with the credentials you set up earlier.
   - If you didn't create a new MySQL user, use `'root'` as the user and your root password.

3. Save the `db_config.py` File.

--------------------------------------------------------------------------------------------------------------------------------------

**Run the Game**

3. Follow the On-Screen Prompts:

   - Register a New User:

     - Choose the option to register.
     - Provide a username and password.

   - Login:

     - After registration, log in with your credentials.

   - Play the Game:

     - Select the option to play the game.
     - Choose a difficulty level.
     - Enjoy playing!

--------------------------------------------------------------------------------------------------------------------------------------

Happy Gaming! :)