# main.py

from Game import Game
from user_auth import register_user, login_user, get_user_stats, get_leaderboard

def main():
    while True:
        print("\nWelcome to Escape the Kidnappers!")
        print("1. Login")
        print("2. Register")
        print("3. View Leaderboard")
        print("4. Exit")
        choice = input("Enter your choice (1, 2, 3, or 4): ").strip()

        if choice == '1':
            username = input("Username: ").strip()
            password = input("Password: ").strip()
            user = login_user(username, password)
            if user:
                # User logged in successfully
                print(f"\nWelcome back, {username}!")
                while True:
                    print("\nPlease choose an option:")
                    print("1. Play Game")
                    print("2. View Win-Loss Record")
                    print("3. Logout")
                    sub_choice = input("Enter your choice (1, 2, or 3): ").strip()
                    
                    if sub_choice == '1':
                        # Choose difficulty level
                        print("\nSelect Difficulty Level:")
                        print("1. Easy")
                        print("2. Medium")
                        print("3. Hard")
                        diff_choice = input("Enter your choice (1, 2, or 3): ").strip()

                        if diff_choice == '1':
                            difficulty = 'Easy'
                        elif diff_choice == '2':
                            difficulty = 'Medium'
                        elif diff_choice == '3':
                            difficulty = 'Hard'
                        else:
                            print("Invalid choice. Defaulting to Medium difficulty.")
                            difficulty = 'Medium'

                        game = Game(user['id'], username, difficulty)
                        game.play()
                    elif sub_choice == '2':
                        stats = get_user_stats(user['id'])
                        if stats:
                            wins, losses = stats
                            total_games = wins + losses
                            win_percentage = (wins / total_games * 100) if total_games > 0 else 0
                            print("\nYour Win-Loss Record:")
                            print(f"Wins: {wins}")
                            print(f"Losses: {losses}")
                            print(f"Win Percentage: {win_percentage:.2f}%")
                        else:
                            print("\nUnable to retrieve your stats at this time.")
                    elif sub_choice == '3':
                        print("Logging out...")
                        break
                    else:
                        print("Invalid choice. Please enter 1, 2, or 3.")
            else:
                print("Login failed. Please try again.")
        elif choice == '2':
            username = input("Choose a username: ").strip()
            password = input("Choose a password: ").strip()
            success = register_user(username, password)
            if success:
                print("You can now log in with your new credentials.")
            else:
                print("Registration failed.")
        elif choice == '3':
            # View Leaderboard
            leaderboard = get_leaderboard()
            if leaderboard:
                print("\nLeaderboard:")
                print(f"{'Rank':<5}{'Username':<15}{'Wins':<6}{'Losses':<8}{'Win %':<6}")
                for idx, player in enumerate(leaderboard, start=1):
                    win_percentage = f"{player['win_percentage']:.2f}%"
                    print(f"{idx:<5}{player['username']:<15}{player['wins']:<6}{player['losses']:<8}{win_percentage:<6}")
            else:
                print("\nNo leaderboard data available at this time.")
        elif choice == '4':
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Please enter 1, 2, 3, or 4.")

if __name__ == '__main__':
    main()
