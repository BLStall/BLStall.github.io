# test_db_connection.py

from db_connector import create_connection

def test_connection():
    connection = create_connection()
    if connection:
        print("Database connection successful!")
        connection.close()
    else:
        print("Database connection failed.")

if __name__ == '__main__':
    test_connection()

