package com.example.projecttwo;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class EditActivity extends AppCompatActivity {

    private EditText editedWeightEditText;
    private EditText editedDateEditText;
    private double oldWeight;
    private String oldDate;
    private DatabaseActivity dbHelper;
    private String currentUsername;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        editedWeightEditText = findViewById(R.id.editedWeightEditText);
        editedDateEditText = findViewById(R.id.editDate);

        // Use singleton instance
        dbHelper = DatabaseActivity.getInstance(getApplicationContext());

        // Get the old weight and date values from the intent extras
        oldWeight = getIntent().getDoubleExtra("oldWeight", 0.0);
        oldDate = getIntent().getStringExtra("oldDate");
        currentUsername = getIntent().getStringExtra("currentUsername");

        // Set the old weight and date values in the EditTexts
        editedWeightEditText.setText(String.valueOf(oldWeight));
        editedDateEditText.setText(oldDate);

        // Implement save button functionality if needed
    }
}
