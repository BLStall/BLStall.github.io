package com.example.projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

public class DailyActivity extends AppCompatActivity {

    private DatabaseActivity database;
    private String currentUsername;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daily);

        // Use singleton instance
        database = DatabaseActivity.getInstance(getApplicationContext());

        currentUsername = getIntent().getStringExtra("currentUsername");
        Log.d("Debug", "Current Username: " + currentUsername);

        EditText editTextDate = findViewById(R.id.editTextDate);
        EditText editTextWeight = findViewById(R.id.editTextWeight);
        Button submitButton = findViewById(R.id.submitWeightButton);

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String date = editTextDate.getText().toString().trim();
                String weightText = editTextWeight.getText().toString().trim();

                if (!date.isEmpty() && !weightText.isEmpty()) {
                    try {
                        double weight = Double.parseDouble(weightText);

                        if (database.addWeight(currentUsername, date, weight)) {
                            Intent intent = new Intent(DailyActivity.this, DisplayActivity.class);
                            intent.putExtra("currentUsername", currentUsername);
                            startActivity(intent);
                        } else {
                            Toast.makeText(DailyActivity.this, "Failed to add weight", Toast.LENGTH_SHORT).show();
                        }
                    } catch (NumberFormatException e) {
                        // Handle the exception
                        Log.e("Exception", "Error parsing weight: " + e.getMessage());
                        editTextWeight.setError("Invalid weight value");
                    }
                } else {
                    if (date.isEmpty()) {
                        editTextDate.setError("Please enter a date");
                    }
                    if (weightText.isEmpty()) {
                        editTextWeight.setError("Please enter a weight");
                    }
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // No need to close the database here since we're using a singleton
    }
}
