package com.example.projecttwo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

public class DatabaseActivity extends SQLiteOpenHelper {

    // Constants for database name and version
    private static final String DATABASE_NAME = "AppDatabase";
    private static final int DATABASE_VERSION = 3;

    // Users Table and Column Constants
    public static final String TABLE_USERS = "Users";
    public static final String COLUMN_USER_ID = "ID";
    public static final String COLUMN_USERNAME = "Username";
    public static final String COLUMN_PASSWORD = "Password";
    public static final String COLUMN_PHONE_NUMBER = "PhoneNumber";

    // DailyWeights Table and Column Constants
    public static final String TABLE_DAILY_WEIGHT = "DailyWeights";
    public static final String COLUMN_DAILY_WEIGHT_ID = "weightID";
    public static final String COLUMN_DATE = "Date";
    public static final String COLUMN_WEIGHT = "Weight";

    // GoalWeight Table and Column Constants
    public static final String TABLE_GOAL_WEIGHT = "GoalWeight";
    public static final String COLUMN_GOAL_WEIGHT_ID = "goalID";
    public static final String COLUMN_GOAL = "Goal";

    // Singleton instance
    private static DatabaseActivity instance;

    // Caches to store frequently accessed data
    private final HashMap<String, Integer> userIdCache;
    private final HashSet<String> existingUsernamesCache;
    private final HashMap<String, String> userPhoneNumberCache;
    private final HashMap<String, Double> userGoalWeightCache;

    // Private Constructor
    private DatabaseActivity(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        userIdCache = new HashMap<>();
        existingUsernamesCache = new HashSet<>();
        userPhoneNumberCache = new HashMap<>();
        userGoalWeightCache = new HashMap<>();
        Log.d("DatabaseActivity", "DatabaseActivity instance created.");
    }

    // Method to get the singleton instance
    public static synchronized DatabaseActivity getInstance(Context context) {
        if (instance == null) {
            instance = new DatabaseActivity(context.getApplicationContext());
            Log.d("DatabaseActivity", "New singleton instance created.");
        } else {
            Log.d("DatabaseActivity", "Singleton instance reused.");
        }
        return instance;
    }

    // Create tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create Users Table
        String createUserTable = "CREATE TABLE " + TABLE_USERS + "(" +
                COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_USERNAME + " TEXT," +
                COLUMN_PASSWORD + " TEXT," +
                COLUMN_PHONE_NUMBER + " TEXT" +
                ")";
        db.execSQL(createUserTable);

        // Create DailyWeights Table
        String createWeightTable = "CREATE TABLE " + TABLE_DAILY_WEIGHT + "(" +
                COLUMN_DAILY_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_USER_ID + " INTEGER," +
                COLUMN_DATE + " TEXT," +
                COLUMN_WEIGHT + " REAL," +
                "FOREIGN KEY(" + COLUMN_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USER_ID + "))";
        db.execSQL(createWeightTable);

        // Create GoalWeight Table
        String createGoalWeightTable = "CREATE TABLE " + TABLE_GOAL_WEIGHT + "(" +
                COLUMN_GOAL_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_USER_ID + " INTEGER," +
                COLUMN_GOAL + " REAL," +
                "FOREIGN KEY(" + COLUMN_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USER_ID + "))";
        db.execSQL(createGoalWeightTable);
    }

    // Upgrade database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Clear caches as data may change after upgrade
        userIdCache.clear();
        existingUsernamesCache.clear();
        userPhoneNumberCache.clear();
        userGoalWeightCache.clear();

        // Temporarily store old user data
        List<String> usernames = new ArrayList<>();
        List<String> passwords = new ArrayList<>();
        Cursor cursor = db.query(TABLE_USERS, new String[]{COLUMN_USERNAME, COLUMN_PASSWORD}, null, null, null, null, null);
        int usernameIndex = cursor.getColumnIndex(COLUMN_USERNAME);
        int passwordIndex = cursor.getColumnIndex(COLUMN_PASSWORD);

        while (cursor.moveToNext()) {
            usernames.add(cursor.getString(usernameIndex));
            passwords.add(cursor.getString(passwordIndex));
        }
        cursor.close();

        // Drop all tables
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_DAILY_WEIGHT);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOAL_WEIGHT);

        // Recreate tables
        onCreate(db);

        // Restore old user data
        for (int i = 0; i < usernames.size(); i++) {
            ContentValues values = new ContentValues();
            values.put(COLUMN_USERNAME, usernames.get(i));
            values.put(COLUMN_PASSWORD, passwords.get(i));
            db.insert(TABLE_USERS, null, values);
        }
    }

    // Retrieve user's ID using a cache
    public int getUserId(String username) {
        // Check the cache first
        Integer cachedUserId = userIdCache.get(username);
        if (cachedUserId != null) {
            Log.d("CacheHit", "getUserId: Retrieved userId for '" + username + "' from cache.");
            return cachedUserId;
        }
        Log.d("CacheMiss", "getUserId: UserId for '" + username + "' not in cache. Querying database.");

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + COLUMN_USER_ID + " FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + " = ?", new String[]{username});

        int userId = -1;
        if (cursor.moveToFirst()) {
            int columnIndex = cursor.getColumnIndex(COLUMN_USER_ID);
            if (columnIndex >= 0) {
                userId = cursor.getInt(columnIndex);
                // Add to cache
                userIdCache.put(username, userId);
                Log.d("CacheUpdate", "getUserId: Cached userId for '" + username + "'.");
            } else {
                Log.e("getUserId", "Column " + COLUMN_USER_ID + " not found in cursor.");
            }
        } else {
            Log.e("getUserId", "User not found for username: " + username);
        }

        cursor.close();
        db.close();
        return userId;
    }

    // Validate user credentials
    public boolean isUserValid(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        String[] columns = {COLUMN_USER_ID};
        String selection = COLUMN_USERNAME + " = ? AND " + COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = {username, password};

        Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);

        boolean isValid = cursor.moveToFirst();

        cursor.close();
        db.close();

        return isValid;
    }

    // Check if user exists using a cache
    public boolean isUserExists(String username) {
        // Check the cache first
        if (existingUsernamesCache.contains(username)) {
            Log.d("CacheHit", "isUserExists: Username '" + username + "' found in cache.");
            return true;
        }
        Log.d("CacheMiss", "isUserExists: Username '" + username + "' not in cache. Querying database.");

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT 1 FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + " = ?", new String[]{username});
        boolean exists = cursor.moveToFirst();
        cursor.close();
        db.close();

        // Update the cache if the user exists
        if (exists) {
            existingUsernamesCache.add(username);
            Log.d("CacheUpdate", "isUserExists: Cached username '" + username + "'.");
        }

        return exists;
    }

    // Add a new user and update caches
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_USERNAME, username);
        contentValues.put(COLUMN_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, contentValues);

        if (result != -1) {
            // Update caches
            existingUsernamesCache.add(username);
            Log.d("CacheUpdate", "addUser: Cached username '" + username + "'.");

            // Get the new user ID and add it to the cache
            Cursor cursor = db.rawQuery("SELECT " + COLUMN_USER_ID + " FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + " = ?", new String[]{username});
            if (cursor.moveToFirst()) {
                int columnIndex = cursor.getColumnIndex(COLUMN_USER_ID);
                if (columnIndex >= 0) {
                    int userId = cursor.getInt(columnIndex);
                    userIdCache.put(username, userId);
                    Log.d("CacheUpdate", "addUser: Cached userId for '" + username + "'.");
                } else {
                    Log.e("addUser", "Column " + COLUMN_USER_ID + " not found in cursor.");
                }
            }
            cursor.close();
            db.close();
            return true;
        } else {
            db.close();
            return false;
        }
    }

    // Add a new weight record
    public boolean addWeight(String username, String date, double weight) {
        int userId = getUserId(username);
        if (userId == -1) {
            Log.e("addWeight", "User not found for username: " + username);
            return false;
        }

        SQLiteDatabase db = this.getWritableDatabase();

        db.beginTransaction();
        try {
            ContentValues values = new ContentValues();
            values.put(COLUMN_USER_ID, userId);
            values.put(COLUMN_DATE, date);
            values.put(COLUMN_WEIGHT, weight);

            long result = db.insert(TABLE_DAILY_WEIGHT, null, values);

            if (result == -1) {
                Log.e("SQLiteError", "Failed to insert weight.");
                return false;
            }

            db.setTransactionSuccessful();
            Log.d("addWeight", "Weight record added for userId " + userId);
        } catch (Exception e) {
            Log.e("addWeight", "Exception during insertion: " + e.getMessage());
            return false;
        } finally {
            db.endTransaction();
            db.close();
        }

        return true;
    }

    // Set a goal weight and update cache
    public boolean setGoalWeight(String username, double goal) {
        int userId = getUserId(username);
        if (userId == -1) return false;

        double existingGoal = getGoalWeight(username);
        if (existingGoal != -1) {
            Log.d("setGoalWeight", "Goal weight already exists for user: " + username);
            return false;
        }

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_ID, userId);
        values.put(COLUMN_GOAL, goal);

        long result = db.insert(TABLE_GOAL_WEIGHT, null, values);
        db.close();

        if (result != -1) {
            // Update the cache
            userGoalWeightCache.put(username, goal);
            Log.d("CacheUpdate", "setGoalWeight: Cached goal weight for '" + username + "'.");
            return true;
        } else {
            return false;
        }
    }

    // Retrieve the goal weight using a cache
    public double getGoalWeight(String username) {
        // Check the cache first
        Double cachedGoalWeight = userGoalWeightCache.get(username);
        if (cachedGoalWeight != null) {
            Log.d("CacheHit", "getGoalWeight: Retrieved goal weight for '" + username + "' from cache.");
            return cachedGoalWeight;
        }
        Log.d("CacheMiss", "getGoalWeight: Goal weight for '" + username + "' not in cache. Querying database.");

        int userId = getUserId(username);
        if (userId == -1) return -1.0;

        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT " + COLUMN_GOAL + " FROM " + TABLE_GOAL_WEIGHT + " WHERE " + COLUMN_USER_ID + " = ?";
        Cursor cursor = db.rawQuery(selectQuery, new String[]{String.valueOf(userId)});

        double goal = -1.0;
        if (cursor.moveToFirst()) {
            int columnIndex = cursor.getColumnIndex(COLUMN_GOAL);
            if (columnIndex >= 0) {
                goal = cursor.getDouble(columnIndex);
                // Update the cache
                userGoalWeightCache.put(username, goal);
                Log.d("CacheUpdate", "getGoalWeight: Cached goal weight for '" + username + "'.");
            } else {
                Log.e("getGoalWeight", "Column " + COLUMN_GOAL + " not found in cursor.");
            }
        }

        cursor.close();
        db.close();
        return goal;
    }

    // Update user's phone number and cache
    public void setUserPhoneNumber(String username, String phoneNumber) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_PHONE_NUMBER, phoneNumber);

        db.update(TABLE_USERS, values, COLUMN_USERNAME + " = ?", new String[]{username});
        db.close();

        // Update the cache
        userPhoneNumberCache.put(username, phoneNumber);
        Log.d("CacheUpdate", "setUserPhoneNumber: Cached phone number for '" + username + "'.");
    }

    // Retrieve user's phone number using a cache
    public String getUserPhoneNumber(String username) {
        // Check the cache first
        String cachedPhoneNumber = userPhoneNumberCache.get(username);
        if (cachedPhoneNumber != null) {
            Log.d("CacheHit", "getUserPhoneNumber: Retrieved phone number for '" + username + "' from cache.");
            return cachedPhoneNumber;
        }
        Log.d("CacheMiss", "getUserPhoneNumber: Phone number for '" + username + "' not in cache. Querying database.");

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_USERS, new String[]{COLUMN_PHONE_NUMBER},
                COLUMN_USERNAME + " = ?", new String[]{username}, null, null, null);

        String phoneNumber = null;
        if (cursor.moveToFirst()) {
            int columnIndex = cursor.getColumnIndex(COLUMN_PHONE_NUMBER);
            if (columnIndex >= 0) {
                phoneNumber = cursor.getString(columnIndex);
                // Update the cache
                userPhoneNumberCache.put(username, phoneNumber);
                Log.d("CacheUpdate", "getUserPhoneNumber: Cached phone number for '" + username + "'.");
            } else {
                Log.e("getUserPhoneNumber", "Column " + COLUMN_PHONE_NUMBER + " not found in cursor.");
            }
        } else {
            Log.d("getUserPhoneNumber", "No phone number found for username: " + username);
        }

        cursor.close();
        db.close();
        return phoneNumber;
    }

    // Retrieve the latest daily weight
    public double getLatestDailyWeight(String username) {
        int userId = getUserId(username);
        if (userId == -1) return -1.0;

        SQLiteDatabase db = this.getReadableDatabase();
        double weight = -1.0;

        Cursor cursor = db.query(
                TABLE_DAILY_WEIGHT,
                new String[]{COLUMN_WEIGHT},
                COLUMN_USER_ID + " = ?",
                new String[]{String.valueOf(userId)},
                null,
                null,
                COLUMN_DATE + " DESC",
                "1"
        );

        if (cursor.moveToFirst()) {
            int columnIndex = cursor.getColumnIndex(COLUMN_WEIGHT);
            if (columnIndex >= 0) {
                weight = cursor.getDouble(columnIndex);
            } else {
                Log.e("getLatestDailyWeight", "Column " + COLUMN_WEIGHT + " not found in cursor.");
            }
        }

        cursor.close();
        db.close();

        return weight;
    }

    // Retrieve all weight data for a user
    public ArrayList<String> getAllWeightData(String username) {
        int userId = getUserId(username);
        if (userId == -1) return new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<String> data = new ArrayList<>();

        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_DAILY_WEIGHT + " WHERE " + COLUMN_USER_ID + " = ?", new String[]{String.valueOf(userId)});
        if (cursor.moveToFirst()) {
            do {
                int dateIndex = cursor.getColumnIndex(COLUMN_DATE);
                int weightIndex = cursor.getColumnIndex(COLUMN_WEIGHT);

                if (dateIndex >= 0 && weightIndex >= 0) {
                    String date = cursor.getString(dateIndex);
                    double weight = cursor.getDouble(weightIndex);
                    data.add(weight + ": " + date);
                } else {
                    Log.e("getAllWeightData", "Columns not found in cursor.");
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return data;
    }

    // Update weight and date data
    public boolean updateWeightAndDateData(double oldWeight, String oldDate, double newWeight, String newDate) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_WEIGHT, newWeight);
        values.put(COLUMN_DATE, newDate);

        int updatedRows = db.update(TABLE_DAILY_WEIGHT, values,
                COLUMN_WEIGHT + " = ? AND " + COLUMN_DATE + " = ?",
                new String[]{String.valueOf(oldWeight), oldDate});

        db.close();

        return updatedRows > 0;
    }

    // Delete weight data
    public boolean deleteWeightData(double oldWeight, String oldDate) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsDeleted = db.delete(
                TABLE_DAILY_WEIGHT,
                COLUMN_WEIGHT + " = ? AND " + COLUMN_DATE + " = ?",
                new String[]{String.valueOf(oldWeight), oldDate}
        );
        db.close();
        return rowsDeleted > 0;
    }
}
