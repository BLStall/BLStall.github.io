package com.example.projecttwo;

import android.Manifest;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.Context;
import android.database.Cursor;
import android.telephony.SmsManager;
import android.util.Log;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;

import java.util.ArrayList;
import java.util.List;

public class DatabaseActivity extends SQLiteOpenHelper {

    // Constants for database name and version
    private static final String DATABASE_NAME = "AppDatabase";
    private static final int DATABASE_VERSION = 3;
    private static final int SMS_PERMISSION_REQUEST_CODE = 1001;

    // Users Table Constants
    public static final String TABLE_USERS = "Users";
    public static final String COLUMN_USER_ID = "ID";
    public static final String COLUMN_USERNAME = "Username";
    public static final String COLUMN_PASSWORD = "Password";
    public static final String COLUMN_PHONE_NUMBER = "PhoneNumber";

    // DailyWeights Table Constants
    public static final String TABLE_DAILY_WEIGHT = "DailyWeights";
    public static final String COLUMN_DAILY_WEIGHT_ID = "weightID";
    public static final String COLUMN_DATE = "Date";
    public static final String COLUMN_WEIGHT = "Weight";

    // GoalWeight Table Constants
    public static final String TABLE_GOAL_WEIGHT = "GoalWeight";
    public static final String COLUMN_GOAL_WEIGHT_ID = "goalID";
    public static final String COLUMN_GOAL = "Goal";

    // Constructor
    public DatabaseActivity(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Create tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create Users Table
        String createUserTable = "CREATE TABLE " + TABLE_USERS + "(" +
                COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_USERNAME + " TEXT," +
                COLUMN_PASSWORD + " TEXT," +
                COLUMN_PHONE_NUMBER + " TEXT" +
                ")";
        db.execSQL(createUserTable);

        // Create DailyWeights Table
        String createWeightTable = "CREATE TABLE " + TABLE_DAILY_WEIGHT + "(" +
                COLUMN_DAILY_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_USER_ID + " INTEGER," +
                COLUMN_DATE + " TEXT," +
                COLUMN_WEIGHT + " REAL," +
                "FOREIGN KEY(" + COLUMN_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USER_ID + "))";
        db.execSQL(createWeightTable);

        // Create GoalWeight Table
        String createGoalWeightTable = "CREATE TABLE " + TABLE_GOAL_WEIGHT + "(" +
                COLUMN_GOAL_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_USER_ID + " INTEGER," +
                COLUMN_GOAL + " REAL," +
                "FOREIGN KEY(" + COLUMN_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USER_ID + "))";
        db.execSQL(createGoalWeightTable);
    }

    // Upgrade database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Temporarily store old user data
        List<String> usernames = new ArrayList<>();
        List<String> passwords = new ArrayList<>();
        Cursor cursor = db.query(TABLE_USERS, new String[]{COLUMN_USERNAME, COLUMN_PASSWORD}, null, null, null, null, null);
        int usernameIndex = cursor.getColumnIndex(COLUMN_USERNAME);
        int passwordIndex = cursor.getColumnIndex(COLUMN_PASSWORD);

        while (cursor.moveToNext()) {
            usernames.add(cursor.getString(usernameIndex));
            passwords.add(cursor.getString(passwordIndex));
        }
        cursor.close();

        // Drop all tables
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_DAILY_WEIGHT);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOAL_WEIGHT);

        // Recreate tables
        onCreate(db);

        // Restore old user data
        for (int i = 0; i < usernames.size(); i++) {
            ContentValues values = new ContentValues();
            values.put(COLUMN_USERNAME, usernames.get(i));
            values.put(COLUMN_PASSWORD, passwords.get(i));
            db.insert(TABLE_USERS, null, values);
        }
    }

    // This method is used to get a user's ID from the username
    public int getUserId(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + COLUMN_USER_ID + " FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + " = ?", new String[]{username});

        if (cursor.moveToFirst()) {
            int columnIndex = cursor.getColumnIndex(COLUMN_USER_ID);
            if (columnIndex != -1) {
                int userId = cursor.getInt(columnIndex);
                Log.d("Debug", "UserId retrieved for username '" + username + "': " + userId);
                cursor.close();
                return userId;
            } else {
                Log.e("Debug", "UserId column index not found in cursor for username: " + username);
            }
        } else {
            Log.e("Debug", "No data retrieved for username: " + username);
        }

        cursor.close();
        return -1;
    }


    // Check if a user with a specific username and password exists in the database
    public boolean isUserValid(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        String[] columns = {COLUMN_USER_ID};
        String selection = COLUMN_USERNAME + " = ? AND " + COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = {username, password};

        Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);

        boolean isValid = cursor.moveToFirst();

        cursor.close();
        db.close();

        return isValid;
    }

    // Check if a user with a specific username already exists in the database
    public boolean isUserExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + " = ?", new String[]{username});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    // Add a new user to the users table
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_USERNAME, username);
        contentValues.put(COLUMN_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, contentValues);
        db.close();
        return result != -1;
    }

    // Add a new weight record to DailyWeights table
    public boolean addWeight(String username, String date, double weight) {
        Log.d("Debug", "Inside addWeight - Username: " + username + ", Date: " + date + ", Weight: " + weight);

        int userId = getUserId(username);
        long result = -1;  // Initialize the result variable

        if (userId == -1) {
            Log.d("Debug", "User not found for username: " + username);
            return false;  // If user is not found, return false
        }

        SQLiteDatabase db = this.getWritableDatabase();

        // Start a transaction
        db.beginTransaction();

        try {
            ContentValues values = new ContentValues();
            values.put(COLUMN_USER_ID, userId);
            values.put(COLUMN_DATE, date);
            values.put(COLUMN_WEIGHT, weight);

            Log.d("Debug", "Attempting to insert - UserId: " + userId + ", Date: " + date + ", Weight: " + weight);

            result = db.insert(TABLE_DAILY_WEIGHT, null, values);

            if (result == -1) {
                Log.e("SQLiteError", "Failed to insert weight. Possible database error.");
            } else {
                Log.d("Debug", "Weight inserted successfully. Row ID: " + result);
            }

            // Set the transaction as successful
            db.setTransactionSuccessful();
        } catch (SQLiteException e) {
            Log.e("SQLiteException", "Exception during insertion: " + e.getMessage());
            e.printStackTrace();
        } finally {
            // End the transaction
            db.endTransaction();
            db.close();
        }

        return result != -1;
    }

    // Set a goal weight in GoalWeight table
    public boolean setGoalWeight(String username, double goal) {
        int userId = getUserId(username);
        if (userId == -1) return false;  // If user is not found, return false

        // Check if a goal weight already exists for the user
        double existingGoal = getGoalWeight(username);
        if (existingGoal != -1) {
            Log.d("Debug", "Goal weight already exists for user: " + username);
            return false;  // Return false if a goal weight already exists
        }

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_ID, userId);
        values.put(COLUMN_GOAL, goal);

        long result = db.insert(TABLE_GOAL_WEIGHT, null, values);
        db.close();
        return result != -1;
    }


    // Retrieve the goal weight from GoalWeight table
    public double getGoalWeight(String username) {
        int userId = getUserId(username);
        if (userId == -1) return -1.0;  // If user is not found, return -1.0

        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT * FROM " + TABLE_GOAL_WEIGHT + " WHERE " + COLUMN_USER_ID + " = ?";
        Cursor cursor = db.rawQuery(selectQuery, new String[]{String.valueOf(userId)});


        if (cursor.moveToFirst()) {
            // Check if the cursor contains the COLUMN_GOAL data
            int columnIndex = cursor.getColumnIndex(COLUMN_GOAL);
            if (columnIndex >= 0) {
                double goal = cursor.getDouble(columnIndex);
                cursor.close(); // Close the cursor after retrieving data
                return goal;
            } else {
                // Log an error if the COLUMN_GOAL index is -1
                Log.e("getGoalWeight", "Failed to retrieve goal weight. Column index is -1.");
            }
        }

        cursor.close(); // Close the cursor in case the query didn't move to first or there was an issue
        return -1.0; // Return a default value or appropriate value indicating an error

    }

    public void setUserPhoneNumber(String username, String phoneNumber) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_PHONE_NUMBER, phoneNumber);

        db.update(TABLE_USERS, values, COLUMN_USERNAME + " = ?", new String[]{username});
        db.close();
    }
    public double getLatestDailyWeight(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        double weight = -1;

        // Query to get the latest daily weight for the given username
        Cursor cursor = db.query(
                TABLE_DAILY_WEIGHT,
                new String[]{COLUMN_WEIGHT},
                COLUMN_USER_ID + " = ?",
                new String[]{String.valueOf(getUserId(username))},
                null,
                null,
                COLUMN_DATE + " DESC",
                "1"
        );

        if (cursor.moveToFirst()) {
            int weightColumnIndex = cursor.getColumnIndex(COLUMN_WEIGHT);
            if (weightColumnIndex != -1) {
                weight = cursor.getDouble(weightColumnIndex);
            }
        }

        cursor.close();
        db.close();

        return weight;
    }

    // Retrieve all weight data from DailyWeights table
    public ArrayList<String> getAllWeightData(String username) {
        int userId = getUserId(username);
        if (userId == -1) return new ArrayList<>();  // If user is not found, return an empty list

        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<String> data = new ArrayList<>();

        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_DAILY_WEIGHT + " WHERE " + COLUMN_USER_ID + " = ?", new String[]{String.valueOf(userId)});
        if (cursor.moveToFirst()) {
            do {
                int dateIndex = cursor.getColumnIndex(COLUMN_DATE);
                int weightIndex = cursor.getColumnIndex(COLUMN_WEIGHT);

                if (dateIndex != -1 && weightIndex != -1) { // Ensure column indices are valid
                    String date = cursor.getString(dateIndex);
                    double weight = cursor.getDouble(weightIndex);
                    data.add(weight + ": " + date);
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        return data;
    }
    // Update both weight and date data in the DailyWeights table
    public boolean updateWeightAndDateData(double oldWeight, String oldDate, double newWeight, String newDate) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_WEIGHT, newWeight);
        values.put(COLUMN_DATE, newDate);

        // Update the row based on old weight and old date values
        int updatedRows = db.update(TABLE_DAILY_WEIGHT, values,
                COLUMN_WEIGHT + " = ? AND " + COLUMN_DATE + " = ?",
                new String[]{String.valueOf(oldWeight), oldDate});

        db.close();

        // Return true if at least one row was updated
        return updatedRows > 0;
    }



    // Delete weight data from DailyWeights table based on date
    public boolean deleteWeightData(double oldWeight, String oldDate) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsDeleted = db.delete(
                TABLE_DAILY_WEIGHT,
                COLUMN_WEIGHT + " = ? AND " + COLUMN_DATE + " = ?",
                new String[]{String.valueOf(oldWeight), oldDate}
        );
        db.close();
        return rowsDeleted > 0;
    }

    // Add a method to retrieve user's phone number
    public String getUserPhoneNumber(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        // Verify that COLUMN_PHONE_NUMBER matchesactual column name
        Cursor cursor = db.query(TABLE_USERS, new String[]{COLUMN_PHONE_NUMBER},
                COLUMN_USERNAME + " = ?", new String[]{username}, null, null, null);

        String phoneNumber = null;
        if (cursor.moveToFirst()) {
            // Check if the cursor contains the COLUMN_PHONE_NUMBER data
            int columnIndex = cursor.getColumnIndex(COLUMN_PHONE_NUMBER);
            if (columnIndex >= 0) {
                phoneNumber = cursor.getString(columnIndex);
            } else {
                // Log an error if the COLUMN_PHONE_NUMBER index is -1
                Log.e("getUserPhoneNumber", "Failed to retrieve phone number. Column index is -1.");
            }
        } else {
            // Handle the case where no data was found for the given username
            Log.d("getUserPhoneNumber", "No phone number found for username: " + username);
        }

        cursor.close(); // Always close the cursor to release resources
        return phoneNumber;
    }
}

