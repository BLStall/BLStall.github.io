package com.example.projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

public class DailyActivity extends AppCompatActivity {

    private DatabaseActivity database;
    private String currentUsername;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daily);

        database = new DatabaseActivity(this);

        currentUsername = getIntent().getStringExtra("currentUsername");
        Log.d("Debug", "Current Username: " + currentUsername);

        EditText editTextDate = findViewById(R.id.editTextDate);
        EditText editTextWeight = findViewById(R.id.editTextWeight);
        Button submitButton = findViewById(R.id.submitWeightButton);

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    String date = editTextDate.getText().toString();
                    double weight = Double.parseDouble(editTextWeight.getText().toString());

                    if (database.addWeight(currentUsername, date, weight)) {
                        Intent intent = new Intent(DailyActivity.this, DisplayActivity.class);
                        intent.putExtra("currentUsername", currentUsername);
                        startActivity(intent);
                    } else {
                        Toast.makeText(DailyActivity.this, "Failed to add weight", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    // Handle the exception
                    Log.e("Exception", "Error adding weight: " + e.getMessage());
                    Toast.makeText(DailyActivity.this, "An error occurred", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

        @Override
    protected void onDestroy() {
        super.onDestroy();
        // Close the database connection when the activity is destroyed
        database.close();
    }
}