package com.example.projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class NumberActivity extends AppCompatActivity {

    private String currentUsername;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_number);

        currentUsername = getIntent().getStringExtra("currentUsername");

        Button submitPhoneButton = findViewById(R.id.submitPhoneButton);
        submitPhoneButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onSubmitButtonClick(view);
            }
        });
    }

    public void onSubmitButtonClick(View view) {
        EditText phoneNumberEditText = findViewById(R.id.phoneNumberEditText);
        String phoneNumber = phoneNumberEditText.getText().toString();

        // Save the phone number to the database
        DatabaseActivity dbHelper = new DatabaseActivity(this);
        dbHelper.setUserPhoneNumber(currentUsername, phoneNumber);

        Toast.makeText(this, "Phone number saved.", Toast.LENGTH_SHORT).show();

        navigateToDisplayActivity();
    }

    private void navigateToDisplayActivity() {
        Intent intent = new Intent(this, DisplayActivity.class);
        intent.putExtra("currentUsername", currentUsername);
        startActivity(intent);
    }
}