package com.example.projecttwo;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.Manifest;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class PermissionActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_REQUEST_CODE = 1001;
    private String currentUsername; // Store the username

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission);

        currentUsername = getIntent().getStringExtra("currentUsername"); // Retrieve the username from the intent
    }

    public void onGivePermissionClick(View view) {
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
    }

    public void onDenyPermissionClick(View view) {
        navigateToDisplayActivity();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                navigateToNumberActivity();
            } else {
                navigateToDisplayActivity();
            }
        }
    }

    private void navigateToNumberActivity() {
        Intent intent = new Intent(this, NumberActivity.class);
        intent.putExtra("currentUsername", currentUsername); // Pass the username to the next activity
        startActivity(intent);
        finish();
    }

    private void navigateToDisplayActivity() {
        Intent intent = new Intent(this, DisplayActivity.class);
        intent.putExtra("currentUsername", currentUsername); // Pass the username to the next activity
        startActivity(intent);
        finish();
    }
}