package com.example.projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class GoalActivity extends AppCompatActivity {

    private DatabaseActivity database;
    private EditText goalWeightEditText;
    private Button saveButton;
    private String currentUsername;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal);

        // Retrieve currentUsername from the intent
        currentUsername = getIntent().getStringExtra("currentUsername");

        database = new DatabaseActivity(this);
        goalWeightEditText = findViewById(R.id.goalWeightEditText);
        saveButton = findViewById(R.id.saveButton);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double goalWeight = Double.parseDouble(goalWeightEditText.getText().toString());

                // Pass currentUsername to setGoalWeight method
                if (database.setGoalWeight(currentUsername, goalWeight)) {
                    // Successfully saved goal weight, navigate to PermissionActivity
                    Intent intent = new Intent(GoalActivity.this, PermissionActivity.class);
                    intent.putExtra("currentUsername", currentUsername); // pass currentUsername to PermissionActivity
                    startActivity(intent);
                } else {
                    // Handle unsuccessful goal saving
                    goalWeightEditText.setError("Failed to save goal weight");
                }
            }
        });
    }
}