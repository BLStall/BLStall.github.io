package com.example.projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    private DatabaseActivity database;
    private EditText usernameEditText;
    private EditText passwordEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        database = new DatabaseActivity(this);
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        Button signUpButton = findViewById(R.id.signUpButton);

        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                if (!username.isEmpty() && !password.isEmpty()) {
                    if (!database.isUserExists(username)) {
                        if (database.addUser(username, password)) {
                            // Successfully registered, navigate to DisplayActivity
                            Intent intent = new Intent(RegisterActivity.this, DisplayActivity.class);
                            intent.putExtra("currentUsername", username);
                            startActivity(intent);
                        } else {
                            // Handle unsuccessful registration
                            passwordEditText.setError("Registration failed. Please try again.");
                        }
                    } else {
                        // Handle case when username already exists
                        usernameEditText.setError("Username already exists");
                    }
                } else {
                    // Handle empty fields
                    usernameEditText.setError("Please enter a username");
                    passwordEditText.setError("Please enter a password");
                }
            }
        });
    }
}