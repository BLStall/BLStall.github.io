package com.example.projecttwo;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.telephony.SmsManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.util.ArrayList;

public class DisplayActivity extends AppCompatActivity {

    private DatabaseActivity dbHelper;
    private ArrayAdapter<String> gridViewAdapter;
    private ArrayList<String> weightData;
    private int selectedPosition;
    private String currentUsername;
    private static final int SMS_PERMISSION_REQUEST_CODE = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        dbHelper = new DatabaseActivity(this);

        Button setGoalWeightButton = findViewById(R.id.setGoalWeightButton);
        Button addDataButton = findViewById(R.id.addDataButton);
        GridView dataGridView = findViewById(R.id.dataGridView);

        currentUsername = getIntent().getStringExtra("currentUsername");

        setGoalWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double goalWeight = dbHelper.getGoalWeight(currentUsername);

                if (goalWeight == -1) {
                    Intent intent = new Intent(DisplayActivity.this, GoalActivity.class);
                    intent.putExtra("currentUsername", currentUsername);
                    startActivity(intent);
                } else {
                    // Display a message to the user that the goal weight is already set
                    Toast.makeText(DisplayActivity.this, "Goal weight is already set", Toast.LENGTH_SHORT).show();
                }
            }
        });

        addDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(DisplayActivity.this, DailyActivity.class);
                intent.putExtra("currentUsername", currentUsername);
                startActivity(intent);
            }
        });

        weightData = dbHelper.getAllWeightData(currentUsername);
        gridViewAdapter = new ArrayAdapter<String>(this, R.layout.grid_item_layout, R.id.weightTextView, weightData) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                if (convertView == null) {
                    convertView = getLayoutInflater().inflate(R.layout.grid_item_layout, parent, false);
                }

                TextView entryNumberTextView = convertView.findViewById(R.id.entryNumberTextView);
                TextView weightTextView = convertView.findViewById(R.id.weightTextView);

                String weightEntry = weightData.get(position);
                entryNumberTextView.setText(String.valueOf(position + 1 + ".")); // Set entry number
                weightTextView.setText(weightEntry); // Set weight data

                return convertView;
            }
        };

        dataGridView.setAdapter(gridViewAdapter);

        dataGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                selectedPosition = position; // Set the selected position
                String selectedItem = weightData.get(position);
                String[] parts = selectedItem.split(": ");
                double oldWeight = Double.parseDouble(parts[0]);
                String oldDate = parts[1]; // Extract old date from the selected item

                showEditDeleteDialog(oldWeight, oldDate);
            }
        });

        checkSmsPermission();
    }

    private void checkSmsPermission() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            initiateSmsNotification();
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
        }
    }

    private void initiateSmsNotification() {
        double dailyWeight = dbHelper.getLatestDailyWeight(currentUsername);
        compareWeightAndSendSms(dailyWeight);
    }

    private void compareWeightAndSendSms(double dailyWeight) {
        double goalWeight = dbHelper.getGoalWeight(currentUsername);

        if (goalWeight != -1 && dailyWeight <= goalWeight) {
            String phoneNumber = dbHelper.getUserPhoneNumber(currentUsername);
            String congratulatoryMessage = "Congratulations! You've reached your goal weight.";

            sendSms(phoneNumber, congratulatoryMessage);
        }
    }

    private void sendSms(String phoneNumber, String message) {
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(phoneNumber, null, message, null, null);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                initiateSmsNotification();
            } else {
                Toast.makeText(this, "SMS permission denied.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void showEditDeleteDialog(final double oldWeight, final String oldDate) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Options")
                .setItems(new CharSequence[]{"Edit", "Delete"}, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int which) {
                        if (which == 0) {
                            showEditDialog(oldWeight, oldDate);
                        } else if (which == 1) {
                            confirmDeleteWeightDialog(oldWeight, oldDate, selectedPosition);
                        }
                    }
                });
        builder.create().show();
    }

    private void confirmDeleteWeightDialog(final double oldWeight, final String oldDate, final int selectedPosition) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Confirm Delete")
                .setMessage("Are you sure you want to delete this weight data?")
                .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        deleteWeightData(oldWeight, oldDate, selectedPosition);
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                });
        builder.create().show();
    }

    private void showEditDialog(double oldWeight, String oldDate) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.activity_edit, null);

        final EditText editedWeightEditText = dialogView.findViewById(R.id.editedWeightEditText);
        final EditText editedDateEditText = dialogView.findViewById(R.id.editDate);

        editedWeightEditText.setText(String.valueOf(oldWeight));
        editedDateEditText.setText(oldDate);

        builder.setView(dialogView)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        String newWeightText = editedWeightEditText.getText().toString();
                        String newDate = editedDateEditText.getText().toString();

                        if (!newWeightText.isEmpty()) {
                            double newWeight = Double.parseDouble(newWeightText);

                            weightData.set(selectedPosition, newWeight + ": " + newDate);
                            gridViewAdapter.notifyDataSetChanged();

                            dbHelper.updateWeightAndDateData(oldWeight, oldDate, newWeight, newDate);
                        }
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();
                    }
                });
        builder.create().show();
    }

    private void deleteWeightData(double oldWeight, String oldDate, int selectedPosition) {
        boolean deleted = dbHelper.deleteWeightData(oldWeight, oldDate);

        if (deleted) {
            weightData.remove(selectedPosition);
            gridViewAdapter.notifyDataSetChanged();
        } else {
            Toast.makeText(this, "Failed to delete weight data", Toast.LENGTH_SHORT).show();
        }
    }
}