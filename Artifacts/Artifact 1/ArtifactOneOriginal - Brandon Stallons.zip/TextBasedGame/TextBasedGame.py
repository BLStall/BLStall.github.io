# Brandon Stallons
# Sample function showing the goal of the game and move commands
def show_instructions():
    print("Escape the Kidnappers Game")
    print("Find all 6 items before reaching the final room or all of you will DIE!")
    print("Move commands: North, South, East, West")
    print("Add to Inventory: 'item name'")
    print("-----------------------------------")


# dictionary 
rooms = {
        'Cell #1': {'East': 'the Interrogation Room'},
        'the Interrogation Room': {'North': 'Cell #2', 'South': 'Hall #1', 'East': 'Hall #2', 'West': 'Cell #1'},
        'Cell #2': {'East': 'Cell #3', 'South': 'the Interrogation Room'},
        'Cell #3': {'West': 'Cell #2'},
        'Hall #2': {'West': 'the Interrogation Room', 'North': 'the Front Entrance'},
        'the Front Entrance': {'South': 'Hall #2'},
        'Hall #1': {'North': 'the Interrogation Room', 'East': 'Cell #4'},
        "Cell #4": {'West': 'Hall #1'}
    }
# Shows all of the items
# i had the items and rooms all combined but was getting an error, so i separated them and everything worked
# i also had to include NONE becuase all rooms required an item.
items = {
   'Cell #1': 'key',
   'the Interrogation Room': 'NONE',  
   'Cell #2': 'daughter',
   'Cell #3': 'son',
   'Hall #2': 'machete',
   'Hall #1': 'wooden bat',
   'Cell #4': 'wife'
}

state = 'Cell #1'
inventory = []



def get_new_state(state, direction):
    new_state = state
    for i in rooms:
        if i == state:
            if direction in rooms[i]:
                new_state = rooms[i][direction]

    return new_state  


show_instructions()
while 1:  # gameplay loop
    print('You are in', state)  
    if state == 'the Front Entrance':
        print('You are fighting your kidnappers', end='')
        for i in range(50):
            for j in range(1000000):
                pass
            print(".", end='', flush=True)
        print()
        if len(inventory) == 6:
            print('CONGRATULATIONS! You all survived and escaped!!!')  
        else:
            print('You all have been murdered.. GAME OVER!!')  
        break

    print('Item in room:', items[state])  
    print('Inventory: ', inventory)  
    print('--------------------------------------------------------')  
    direction = input("Enter 'North/South/East/West' to move rooms. Enter the 'item name' to store it. Enter 'Exit' to quit! ")  
    print('--------------------------------------------------------')  
    if direction.lower() == items[state].lower():
        if items[state] not in inventory:
            inventory.append(items[state])  
        continue
    direction = direction.capitalize()  
    if direction == 'Exit':  
        print('Thank your for playing. I hope you enjoyed the game! \U0001f600')  
        exit(0)  
    if direction == 'North' or direction == 'South' or direction == 'East' or direction == 'West':  # if
        new_state = get_new_state(state, direction)
        if new_state == state:  
            print('The key does not work on that door! Enter a new direction!')  
        else:
            state = new_state  
    else:
        print('That is NOT an option!')  

