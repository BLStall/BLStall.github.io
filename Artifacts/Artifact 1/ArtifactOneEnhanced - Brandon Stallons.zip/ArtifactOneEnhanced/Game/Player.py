# Brandon Stallons

class Player:
    # Represents the player in the game.

    def __init__(self, starting_room, room_names):
        # Initializes the player with a starting room, an empty inventory, and a list of rescued family members.

        self.current_room = starting_room
        self.previous_room = None  # To keep track of the previous room
        self.inventory = []
        self.family_members = []
        self.room_names = room_names
        self.hp = 100  # Player health points

    def move(self, direction, rooms):
        """
        Moves the player to a new room based on the direction, checking for access restrictions.

        param direction: The direction to move ('North', 'South', 'East', 'West', 'Up', 'Down').
        param rooms: Dictionary containing room connections.
        return: Tuple (bool, str) indicating success and a message.
        """
        direction = direction.capitalize()
        if direction in rooms[self.current_room]:
            next_room = rooms[self.current_room][direction]

            # Access restrictions
            if next_room == 'security_room' and 'security card' not in self.inventory:
                return False, "You need a security card to enter the Security Room."
            if next_room == 'armory' and 'key' not in self.inventory:
                return False, "The Armory is locked. You need a key to enter."

            self.previous_room = self.current_room  # Update previous room
            self.current_room = next_room
            return True, f"You move to the {self.room_names.get(self.current_room, self.current_room)}."
        else:
            return False, "You can't go that way!"

    def search_room(self, items):
        """
        Searches the current room for items.

        param items: Dictionary containing items in rooms.
        return: Message indicating the result of the search.
        """
        item = items.get(self.current_room, 'NONE')
        if item != 'NONE' and item not in self.inventory:
            self.inventory.append(item)
            if item in ['daughter', 'son', 'wife']:
                self.family_members.append(item)
                return f"You searched the room and found your {item}!"
            else:
                return f"You searched the room and found: {item}."
        elif item in self.inventory:
            return "You have already searched this room and found all items."
        else:
            return "You searched the room but found nothing of interest."

    def show_inventory(self):
        # Displays the current inventory of the player.

        if self.inventory:
            print(f"- {', '.join(self.inventory)}")
        else:
            print("- (empty)")

    def has_weapon(self):
        # Checks if the player has a weapon. Returns 'True' if player has a weapon, 'False' otherwise.

        return any(item in self.inventory for item in ['machete', 'wooden bat', 'gun'])

    def use_item(self, item_name):
        """
        Uses an item from the inventory.

        param item_name: Name of the item to use.
        return: Message indicating the result.
        """
        if item_name in self.inventory:
            if item_name == 'first aid kit':
                old_hp = self.hp  # Store the current HP before healing
                self.hp = min(self.hp + 50, 100)  # Heal up to a maximum of 100 HP
                amount_restored = self.hp - old_hp  # Calculate the actual amount healed
                self.inventory.remove('first aid kit')
                return f"You used the first aid kit and restored {amount_restored} HP."
            else:
                return f"You can't use {item_name} right now."
        else:
            return f"You don't have a {item_name} in your inventory."